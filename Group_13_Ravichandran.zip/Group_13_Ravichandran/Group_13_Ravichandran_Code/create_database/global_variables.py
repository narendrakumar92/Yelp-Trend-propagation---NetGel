#!/usr/bin/python
# coding=utf-8

sqlLite_database_name = 'smlProject.db'
sqlLite_database_name_test = 'smlProject_test.db'
sqlLite_database_name_formatted = 'smlProject_formatted_v1.db'
file_path = '/Users/ravichandran/Documents/Misc/Docs/ASU_Subjects/Spring_17/SML/Project/Code/Yelp-Trend-propagation---NetGel/data/'

added_files = []
#added_files = ['yelp_academic_dataset_user.csv','yelp_academic_dataset_business.csv','yelp_academic_dataset_checkin.csv','yelp_academic_dataset_tip.csv']
file_names = ['yelp_academic_dataset_user.csv','yelp_academic_dataset_business.csv','yelp_academic_dataset_checkin.csv','yelp_academic_dataset_tip.csv','yelp_academic_dataset_review.csv']